# wgertrainer

Using Wger API to access various workouts,this is a package build to help you find the best exercise based on your input of muscle group and available equipment

## Installation

```bash
$ pip install wgertrainer
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`wgertrainer` was created by Shuaitao Tan. It is licensed under the terms of the MIT license.

## Credits

`wgertrainer` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
